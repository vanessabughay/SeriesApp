package com.example.seriesapp

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MasterActivity : AppCompatActivity() {

    private lateinit var recyclerViewSeries: RecyclerView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_master)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        recyclerViewSeries = findViewById(R.id.seriesRV)
        recyclerViewSeries.layoutManager = LinearLayoutManager(this)
        recyclerViewSeries.adapter = SeriesAdapter(this.createSeries(), this)
        recyclerViewSeries.setHasFixedSize(true)
        recyclerViewSeries.addItemDecoration(
            DividerItemDecoration(
                this,
                DividerItemDecoration.VERTICAL
            )
        )

    }
        private fun createSeries(): List<Serie> {
            return listOf(
                Serie(R.drawable.atlanta, " 3 temporadas", "2010")
                Serie(R.drawable.brooklyn_nine_nine, "5 temporadas", "2020")
                Serie(R.drawable.community, "6 temporadas", "2010")
            )
        }

    }
