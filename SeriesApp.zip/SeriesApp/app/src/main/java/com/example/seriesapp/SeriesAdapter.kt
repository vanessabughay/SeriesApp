package com.example.seriesapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView.Adapter
import androidx.recyclerview.widget.RecyclerView.ViewHolder


class SeriesAdapter(
    private val heroes: List<Serie>,
    private val context: Context
) : Adapter<SeriesAdapter.SeriesViewHolder>() {
    inner class SeriesViewHolder(
        private val itemView: View
    ) : ViewHolder(itemView) {
        val serieName = itemView.findViewById<TextView>(R.id.serieName)
        val serieCompany = itemView.findViewById<TextView>(R.id.serieCompany)
        val serieImage = itemView.findViewById<ImageView>(R.id.serieImage)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SeriesViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.list_item, parent, false)
        return SeriesViewHolder(view)
    }

    override fun getItemCount(): Int {
        return heroes.size
    }

    override fun onBindViewHolder(holder: SeriesViewHolder, position: Int) {
        val hero = heroes[position]
        holder.serieName.text = hero.serieName
        holder.serieTemporadas.text = serie.serieTemporadas
        holder.serieAno.setImageResource(serie.serieImage)
    }
}

class serie(
    val serieImage: Int,
    val serieName: String,
    val serieTemporadas: String
){}